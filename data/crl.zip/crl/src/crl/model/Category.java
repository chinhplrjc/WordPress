package crl.model;

import java.util.ArrayList;
import java.util.List;

public class Category {
    public String name;
    public List<Lesson> lessons = new ArrayList<>();
}
