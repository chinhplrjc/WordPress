package crl.model;

import java.util.List;

public class Lesson {
    public String name;
    public String url;
    public List<LessonConent> contents;
}
