package crl;

import com.google.gson.Gson;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import crl.model.Category;
import crl.model.Lesson;
import crl.model.LessonConent;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import javax.net.ssl.SSLSession;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class Test {
    private String baseUrl = "";
    public static void main(String[] args) {
        Test test = new Test();

        List<Category> categories = test.loadCategory();

        for (Category category : categories) {
            for (Lesson lesson : category.lessons) {
                lesson.contents = test.getContent(lesson.url);
                break;
            }
            break;
        }

        test.saveToDisk(categories);

    }

    private void saveToDisk(List<Category> categories){
        for (Category category : categories){
           File catDir = new File("data/" + category.name);
           if(!catDir.exists()){
               catDir.mkdirs();
           }
           for(Lesson lesson : category.lessons){
               File lessionDir = new File(catDir.getAbsolutePath()+"/"+lesson.name);
               if(!lessionDir.exists()){
                   lessionDir.mkdirs();
               }
               if(lesson.contents == null){
                   continue;
               }
               for(LessonConent lc : lesson.contents){
                   String filePath = lessionDir.getAbsoluteFile()+"/"+lc.index;
                   try{
                       Gson gson = new Gson();
                       BufferedWriter br = new BufferedWriter(new FileWriter(new File(filePath)));
                       br.write(gson.toJson(lc));
                       br.flush();
                       br.close();
                   }catch (Exception e){
                       e.printStackTrace();
                   }
               }
           }
        }
    }

    private List<Category> loadCategory() {
        List<Category> result = new ArrayList<>();
        try {
            Document doc = Jsoup.connect("https://www.tutorialspoint.com/tutorialslibrary.htm").get();
            baseUrl = doc.baseUri();

            Elements catElements = doc.select("body > div.container > div.row >div.container > div.row > div.col-md-3 >div.featured-box");
            for (Element catElement : catElements) {
                Elements h4s = catElement.select("h4");
                Elements uls = catElement.select("ul");

                for (int i = 0; i < h4s.size(); i++) {
                    Element h4 = h4s.get(i);
                    Element ul = uls.get(i);

                    Category cat = new Category();
                    cat.name = h4.html();

                    Elements lis = ul.select("li > a");

                    for (Element li : lis) {
                        Lesson lesson = new Lesson();
                        lesson.name = li.html();
                        lesson.url = baseUrl + li.attr("href");
                        lesson.url = lesson.url.replace("com//", "com/");
                        cat.lessons.add(lesson);
                    }
                    result.add(cat);

                }

                break;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    private List<LessonConent> getContent(String url) {
        List<LessonConent> contents = new ArrayList<>();

        try {
            Document doc = Jsoup.connect(url).get();
            Elements menus = doc.body().select("aside.sidebar > ul > li > a");

            for(int i = 0; i < menus.size(); i++){
                LessonConent lc = new LessonConent();
                Element menu = menus.get(i);
                lc.index = i;
                lc.title = menu.html();
                String conentUrl = baseUrl + menu.attr("href");
                conentUrl = conentUrl.replace("com//","com/");
                lc.content = getLessonContent(conentUrl);
                contents.add(lc);
            }
            return contents;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return contents;
    }

    private String getLessonContent(String url) {
        try {
            Document doc = Jsoup.connect(url).get();
            Element content = doc.body().selectFirst("div.content > div.col-md-7");
            if(content == null) {
                System.out.println(url);
                return "";
            }
            String[] csses = {"div.cover","div.pre-btn","div.nxt-btn","div.clearer","div.print-btn","div.bottomgooglead","script","hr"};
            for(String css : csses){
                if(content.select(css) != null){
                    content.select(css).remove();
                }
            }
            String contentStr = content.html().replace("<!-- PRINTING ENDS HERE -->", "");

            return contentStr;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }


}
