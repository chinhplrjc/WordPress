package crl.model;

public class LessonConent {
    public int index;
    public String title;
    public String content;
}
